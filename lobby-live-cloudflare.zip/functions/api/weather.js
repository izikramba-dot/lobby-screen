export async function onRequestGet() {
  const url = "https://api.open-meteo.com/v1/forecast?latitude=32.3215&longitude=34.8532&current=temperature_2m,weather_code&daily=weather_code,temperature_2m_max,temperature_2m_min&timezone=Asia%2FJerusalem&forecast_days=4";
  try {
    const r = await fetch(url,{cf:{cacheTtl:300,cacheEverything:true}});
    if(!r.ok) return new Response(await r.text(),{status:r.status});
    return new Response(await r.text(),{
      headers:{"content-type":"application/json;charset=UTF-8","Cache-Control":"public, max-age=120, s-maxage=300"}
    });
  } catch(e) {
    return Response.json({error:String(e)},{status:500});
  }
}