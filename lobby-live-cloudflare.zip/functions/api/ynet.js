export async function onRequestGet() {
  const rss = "https://www.ynet.co.il/Integration/StoryRss1854.xml";
  try {
    const r = await fetch(rss, {
      headers: {"User-Agent":"Mozilla/5.0 LobbyDisplay/1.0"},
      cf: { cacheTtl: 120, cacheEverything: true }
    });
    if (!r.ok) return Response.json({items:[],error:"ynet upstream "+r.status},{status:502});
    const xml = await r.text();
    const items = [];
    const re = /<item\b[\s\S]*?<title>(?:<!\[CDATA\[)?([\s\S]*?)(?:\]\]>)?<\/title>[\s\S]*?<\/item>/gi;
    let m;
    while ((m = re.exec(xml)) && items.length < 15) {
      const title = m[1]
        .replace(/<!\[CDATA\[|\]\]>/g,"")
        .replace(/&quot;/g,'"').replace(/&amp;/g,'&').replace(/&#39;/g,"'")
        .replace(/<[^>]+>/g,"").trim();
      if (title) items.push({title});
    }
    return Response.json({items,updatedAt:new Date().toISOString()},{
      headers:{"Cache-Control":"public, max-age=60, s-maxage=120"}
    });
  } catch (e) {
    return Response.json({items:[],error:String(e)},{status:500});
  }
}